Khi chay chi vao folder libfdr va chay terminal
Sau do chay lenh : make clean && make
Neu chua cai tool make thi cai
sau do dich chuong trinh bt bang cau lenh: gcc exam.c libfdr/libfdr.a -o exam
Sau do chay chuong trinh bt